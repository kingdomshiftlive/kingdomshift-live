import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shortzz/model/livestream/livestream.dart';
import 'package:shortzz/screen/audio_live_stream_screen/audio_live_stream_controller.dart';

class AudioLiveStreamBottomView extends StatelessWidget {
  final Livestream liveData;
  final AudioLiveStreamController controller;

  const AudioLiveStreamBottomView({
    super.key,
    required this.liveData,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.5),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Row(
        children: [
          Expanded(
            // child: Obx(() => ,),
            child: TextField(
              controller: controller.textCommentController,
              decoration: InputDecoration(
                hintText: 'Write comment',
                hintStyle: const TextStyle(color: Colors.white70),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Colors.white),
                ),
                filled: true,
                fillColor: Colors.white.withValues(alpha: 0.1),
              ),
              style: const TextStyle(color: Colors.white),
              onChanged: (value) {
                controller.isTextEmpty.value = value.trim().isEmpty;
              },
            ),
          ),
          const SizedBox(width: 8),
          Obx(() => IconButton(
              icon: const Icon(Icons.send, color: Colors.white),
              onPressed: controller.isTextEmpty.value
                  ? null
                  : controller.onTextCommentSend,
            ),
          ),
        ],
      ),
    );
  }
}
// File: widget/audio_live_stream_top_view.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shortzz/common/widget/full_name_with_blue_tick.dart';
import 'package:shortzz/languages/languages_keys.dart';
import 'package:shortzz/utilities/text_style_custom.dart';
import 'package:shortzz/utilities/theme_res.dart';
import 'audio_live_stream_controller.dart';

class AudioLiveStreamTopView extends StatelessWidget {
  final bool isAudience;
  final AudioLiveStreamController controller;

  const AudioLiveStreamTopView({
    super.key,
    required this.isAudience,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Obx(() {
              final host = controller.firestoreController.users.firstWhereOrNull((user) => user.userId == controller.liveData.value.hostId);
              return FullNameWithBlueTick(
                username: host?.username ?? '',
                fontColor: whitePure(context),
                fontSize: 14,
                isVerify: host?.isVerify,
              );
            }),
            Row(
              children: [

                Obx(() => Text(
                  '${controller.liveData.value.coHostUsers == null ? '0' : controller.liveData.value.coHostUsers!.length - 1} ${LKey.viewers.tr}',
                  style: TextStyleCustom.outFitRegular400(
                    color: whitePure(context),
                    fontSize: 12,
                  ),
                )),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white),
                  onPressed: () => controller.endStream(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
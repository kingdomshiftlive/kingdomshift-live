import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shortzz/common/controller/firebase_firestore_controller.dart';
import 'package:shortzz/common/manager/logger.dart';
import 'package:shortzz/common/manager/session_manager.dart';
import 'package:shortzz/model/livestream/livestream.dart';
import 'package:shortzz/screen/audio_live_stream_screen/audio_live_stream_screen.dart';
import 'package:zego_express_engine/zego_express_engine.dart';

class CreateAudioLiveStreamController extends GetxController {
  final TextEditingController titleController = TextEditingController();
  final FirebaseFirestore db = FirebaseFirestore.instance;
  final FirebaseFirestoreController firestoreController = Get.find<FirebaseFirestoreController>();

  Future<void> createLiveStream() async {
    final settings = SessionManager.instance.getSettings();
    final appId = int.parse(settings?.zegoAppId ?? '0');
    final appSign = settings?.zegoAppSign ?? '';

    if (appId == 0 || appSign.isEmpty) {
      Loggers.error('Zego App ID or Sign not configured.');
      return;
    }

    try {
      await ZegoExpressEngine.createEngineWithProfile(
        ZegoEngineProfile(appId, ZegoScenario.Default, appSign: appSign),
      );

      final userId = SessionManager.instance.getUserID();
      final roomID = '$userId';
      final liveData = Livestream(
        roomID: roomID,
        hostId: userId,
        // title: titleController.text.trim(),
        type: LivestreamType.livestream,
        watchingCount: 0,
      );

      await db
          .collection('liveStreams')
          .doc(roomID)
          .set(liveData.toJson());

      Get.to(() => AudioLiveStreamScreen(liveData: liveData, isHost: true));
    } catch (e) {
      Loggers.error('Error creating audio live stream: $e');
      Get.snackbar('Error', 'Failed to start live stream.');
    }
  }

  @override
  void onClose() {
    titleController.dispose();
    super.onClose();
  }
}